CUDA_VISIBLE_DEVICES=0,1 python inference.py --data_root /scratch/CS537_2020_Spring/data/VOCdevkit/VOC2012/ \
                --val_path ImageSets/Segmentation/val.txt \
                --img_dir JPEGImages \
                --mask_dir SegmentationClass \
                --model_path /scratch/ONID_username/pySegNet/saved_models/model_best.pth \
                --output_dir /scratch/ONID_username/pySegNet/output \
                --gpu 1
