CUDA_VISIBLE_DEVICES=0,1 python train.py --data_root /scratch/CS537_2020_Spring/data/VOCdevkit/VOC2012/ \
                --train_path ImageSets/Segmentation/train.txt \
                --img_dir JPEGImages \
                --mask_dir SegmentationClass \
                --save_dir /scratch/ONID_username/pySegNet/saved_models/\
                --gpu 1
