Plotting result will be in report.pdf and the image is created from cs537.ipynb
Pytorch source code of CNN1,2,3 will be in keypoint_description.ipynb function name:DesNet, DesNet_2, DesNet_3
